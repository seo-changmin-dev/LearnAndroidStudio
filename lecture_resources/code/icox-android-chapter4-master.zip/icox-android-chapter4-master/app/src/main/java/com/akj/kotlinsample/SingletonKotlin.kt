package com.akj.kotlinsample

object SingletonKotlin {
    fun log(text:String){
        println(text)
    }
}
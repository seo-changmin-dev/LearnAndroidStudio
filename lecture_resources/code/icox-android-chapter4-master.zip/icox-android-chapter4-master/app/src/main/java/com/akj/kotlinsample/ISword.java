package com.akj.kotlinsample;

public interface ISword {
    // 장착메세지를 출력하는 메소드
    void equip();
}

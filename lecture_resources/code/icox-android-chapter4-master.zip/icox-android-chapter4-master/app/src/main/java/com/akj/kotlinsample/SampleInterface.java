package com.akj.kotlinsample;

public interface SampleInterface {
    int plus(int a, int b);
    int calc(int x, int y);
    void print();
}

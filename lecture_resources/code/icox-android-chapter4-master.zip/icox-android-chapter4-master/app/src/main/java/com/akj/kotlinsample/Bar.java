package com.akj.kotlinsample;

public class Bar extends Foo {
    /* Bar 클래스는 다음 코드를 이미 포함하고 있음
    int field1 = 0;

    public int getField1() {
        return field1;
    }

    public void setField1(int field1) {
        this.field1 = field1;
    }
    */
}

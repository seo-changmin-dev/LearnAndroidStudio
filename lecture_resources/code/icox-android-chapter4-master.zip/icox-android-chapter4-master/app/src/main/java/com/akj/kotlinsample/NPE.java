package com.akj.kotlinsample;

public class NPE {
    public int strLen(String text){
        return text.length();
    }
}

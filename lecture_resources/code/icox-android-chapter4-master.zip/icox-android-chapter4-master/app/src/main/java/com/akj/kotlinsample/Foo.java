package com.akj.kotlinsample;

public class Foo {
    int field1 = 0;

    public int getField1() {
        return field1;
    }

    public void setField1(int field1) {
        this.field1 = field1;
    }
}

package com.akj.kotlinsample


// 코틀린의 클래스는 기본적으로 상속불가하다.
class FooKotlin {
    var field1 = 0
}
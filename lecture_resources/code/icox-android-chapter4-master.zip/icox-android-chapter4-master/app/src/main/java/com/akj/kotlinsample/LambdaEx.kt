package com.akj.kotlinsample

val sum = {x:Int, y:Int -> x + y}


package com.akj.kotlinsample

data class Fruit(var fruitName:String, var description:String)
package com.akj.anonymoussns

class Address {
    var country:String = ""
    var state:String = ""
    var provinence:String = ""
    var region:String = ""
}